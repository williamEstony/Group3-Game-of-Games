# Group 3 Game of Games Implementation

## Code Design Documents

* UML Diagrams
* Method Glossary
* Data Configuration Table
* Unit Tests

## Deployment Document

Step-by-step directions indicating how the code for your program (variations) can be accessed, downloaded, configured and run.

## Responsibilities Document

* Rashed Alshamsi: I worked on the EvenOrOdd class and wrote some methods in the GetInput class.  I wrote the UML diagram, methods glossary, data configuration table and unit tests for EvenOrOdd.

* Will Estony:
* Ryan Gress:
* Lewis Nikuze:

## Meeting Notes

* Preliminary Meeting from 1 - 2:30 PM on Friday, November 13, 2020 (Whole Group)  NOTES ALREADY WRITTEN
* Git tutorial from 4 - 4:30 PM on Friday, November 13, 2020 (Will and Rashed)
* Second meeting with group from 5 - 6 PM on Saturday, November 14, 2020 (Whole Group)  NOTES ALREADY WRITTEN
* Third team meeting with group from 1 - 2 PM on Sunday, November 15, 2020 (Whole Group)  NOTES ALREADY WRITTEN
* Fourth team meeting with group from 8 - 9 PM on Sunday, November 15, 2020 (Whole Group) NOTES ALREADY WRITTEN
